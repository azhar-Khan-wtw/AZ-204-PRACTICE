print("Content-Type: text/html\n")
print("<html><body><h1>FastCGI is working!</h1></body></html>")
